import java.io.{ByteArrayInputStream, File}
import java.nio.file.Path
import javax.imageio.ImageIO

import sun.misc.BASE64Decoder

/**
  * Created by Nick on 2/22/2017.
  */
class SimpleService {


  def intent = {
    case req@GET(Path("/get")) => {
      Ok ~> ResponseString(Imap.testImage("data/test2/merino/b.jpg"))
    }

    case req@POST(Path("/get_custom")) => {
      val imageByte = (new BASE64Decoder()).decodeBuffer(Body.string(req));
      val bytes = new ByteArrayInputStream(imageByte)
      val image = ImageIO.read(bytes)
      ImageIO.write(image, "png", new File("image.png"))
    }
      Ok ~> ResponseString(IPApp.testImage("image.png"))
  }
}
object SimpleServer extends Imap {
  val bindingIP = SocketPortBinding(host = "127.0.0.1", port = 8080)
  unfiltered.jetty.Server.portBinding(bindingIP).plan(SimplePlan).run()
}



}
